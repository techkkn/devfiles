import { Component, OnInit } from '@angular/core';
import { AccountService } from '../services/account.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  title = 'app';
  accountList:any;

  count_savings=0;
  count_current=0;
  count_deposit=0;

  constructor(private accountService: AccountService) { }

  ngOnInit(): void {
    this.accountService.getAllAccounts().subscribe(data => {
      this.accountList = data;


      //const words = ['spray', 'elite', 'exuberant', 'destruction', 'present'];

//const result = words.filter((word) => word.length > 6);

//console.log(resu);
// Expected output: Array ["exuberant", "destruction", "present"]


function checkSavingsAccount(acc:any) {
  return acc.accountCategory == "Savings";
}

function checkCurrentAccount(acc:any) {
  return acc.accountCategory == "Current";
}

function checkDepositAccount(acc:any) {
  return acc.accountCategory == "Deposit";
}

this.count_savings =  this.accountList.filter(checkSavingsAccount).length;
this.count_current =  this.accountList.filter(checkCurrentAccount).length;
this.count_deposit =  this.accountList.filter(checkDepositAccount).length;

      console.log(this.accountList)
    });
  }

}
