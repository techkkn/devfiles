import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Account } from '../Account';
import { AccountService } from '../services/account.service';
import { SharedServiceService } from '../services/shared-service.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {

  account: Account = new Account();
  
  successMessage:string ="";
  errMessage: string ="";

  constructor(private accountService:AccountService, private sharedServiceService:SharedServiceService) { 

  }


  ngOnInit(): void {
  }

  addAccountForm=new FormGroup({
    
    accountid:new FormControl('',[Validators.required]),
    accountname:new FormControl('',[Validators.required]),
    branchId: new FormControl('',[Validators.required]),
    category: new FormControl('',[Validators.required]),
    description: new FormControl('',[Validators.required]),
  })

  get accountid(){
    return this.addAccountForm.get('accountid');
  }

  get accountname(){
    return this.addAccountForm.get('accountname');
  }

  get branchId(){
    return this.addAccountForm.get('branchId');
  }

  get category(){
    return this.addAccountForm.get('category');
  }

  get description(){
    return this.addAccountForm.get('description');
  }

  addAccount(){

    this.account.accountId=this.accountid?.value!;
    this.account.accountName=this.accountname?.value!;
    this.account.branchId=Number(this.branchId?.value!);
    this.account.accountCategory=this.category?.value!;
    this.account.accountDescription=this.description?.value!;

    console.log(this.account);


    if(this.account.accountId=="")
    {
      this.errMessage="Account could not be Added : Account Id is required";
    }
    else if(this.account.accountName=="")
    {
      this.errMessage="Account could not be Added : Account Name is required";
    }
    else if(this.account.accountCategory=="")
    {
      this.errMessage="Account could not be Added : Account Category is required";
    }
    else if(this.account.branchId==0  || this.account.branchId==null)
    {
      this.errMessage="Account could not be Added : AccountBranch Id can not be 0";
    }
    else if(this.account.accountDescription=="")
    {
      this.errMessage="Account could not be Added : Account Description is required";
    }
    else{

      this.accountService.addAccount(this.account).subscribe(data => {
       
        if(data)
        {
            this.errMessage="";
            this.successMessage="Account Successfully Added";
        }
        else{
          this.successMessage="";
          this.errMessage="Account could not be Added: Check Details of your account";
        }
  
      })

    }

   
  }


}
