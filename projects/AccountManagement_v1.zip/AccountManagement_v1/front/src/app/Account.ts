export class Account{
    accountId:string;
	accountName:string;
    accountDescription:string;
    accountCategory:string;
    branchId:number;

    constructor(){
        this.accountId="";
        this.accountName="";
        this.accountDescription="";
        this.accountCategory="";
        this.branchId=0;
    }
}