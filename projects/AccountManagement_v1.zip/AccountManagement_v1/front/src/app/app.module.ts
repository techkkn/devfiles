import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GetAccountByCategoryComponent } from './get-account-by-category/get-account-by-category.component';
import { GetAllAccountsComponent } from './get-all-accounts/get-all-accounts.component';
import { AddAccountComponent } from './add-account/add-account.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { MainNavComponent } from './main-nav/main-nav.component';

import {MatDialogModule} from '@angular/material/dialog';

import { AccountService } from './services/account.service';
import { DialogComponent } from './dialog/dialog.component';
import { AuthenticationServiceService } from './services/authentication-service.service';
import { RouterService } from './services/router.service';
import { CanActivateRouteGuard} from './can-activate-guard';


const routes: Routes=[
  {
    path:'login',//path is http:localhost:4200/login
    component:LoginPageComponent
  },
  {
    path:'dashboard',
    component: DashboardComponent,
    canActivate:[CanActivateRouteGuard]
  },
  {
    path:'accountByCategory',//path is http:localhost:4200/accountByCategory
    component:GetAccountByCategoryComponent,
    canActivate:[CanActivateRouteGuard]
  },
  {
    path:'getAllAccounts',//path is http:localhost:4200/getAllAccounts
    component:GetAllAccountsComponent,
    canActivate:[CanActivateRouteGuard]
  },
  {
    path:'add',//path is http:localhost:4200/add
    component:AddAccountComponent,
    canActivate:[CanActivateRouteGuard]
  },
  {
    path:'update',//path is http:localhost:4200/update
    component:UpdateAccountComponent,
    canActivate:[CanActivateRouteGuard]
  },
  {
    //by default we are opening login
        path:'',
        redirectTo:'login',
        pathMatch:'full'
  }
]



@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    DashboardComponent,
    GetAccountByCategoryComponent,
    GetAllAccountsComponent,
    AddAccountComponent,
    UpdateAccountComponent,
    MainNavComponent,
    DialogComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
   
    MatDialogModule
  ],
  providers: [AccountService,AuthenticationServiceService,AuthenticationServiceService,RouterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
