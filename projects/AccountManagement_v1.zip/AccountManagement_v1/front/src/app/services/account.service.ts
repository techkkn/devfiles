import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from '../Account';
import { SharedServiceService } from './shared-service.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient: HttpClient, private sharedServiceService:SharedServiceService) { }

  baseApiUrl="http://localhost:8084/accountManagement/";
  getAllAccounts(): Observable<any> {
    
    return this.httpClient.get<any>(this.baseApiUrl+'getAllAccounts',{
      headers:new HttpHeaders(
        {
          'Authorization' : `Bearer ${localStorage.getItem('token')}`
        }
      )
    });
  }

  addAccount(account:Account): Observable<any>{
    return this.httpClient.post<any>(this.baseApiUrl+'addAccount',account,{
      headers:new HttpHeaders(
        {
          'Authorization' : `Bearer ${localStorage.getItem('token')}`
        }
      )
    });
  }

  getAllAccountsByCategory(category: any): Observable<any> {
    return this.httpClient.get<any>(this.baseApiUrl+`getAccountsByCategory/${category['category']}`,{
      headers:new HttpHeaders(
        {
          'Authorization' : `Bearer ${localStorage.getItem('token')}`
        }
      )
    });
  }

  deleteAccount(accountId: any): Observable<any> {
    return this.httpClient.delete<any>(this.baseApiUrl+`deleteAccount/${accountId}`,{
      headers:new HttpHeaders(
        {
          'Authorization' : `Bearer ${localStorage.getItem('token')}`
        }
      )
    });
  }

  updateAccount(account:Account,accountId: any): Observable<any>{
    return this.httpClient.post<any>(this.baseApiUrl+`updateAccount/${accountId}`,account,{
      headers:new HttpHeaders(
        {
          'Authorization' : `Bearer ${localStorage.getItem('token')}`
        }
      )
    });
  }

}
