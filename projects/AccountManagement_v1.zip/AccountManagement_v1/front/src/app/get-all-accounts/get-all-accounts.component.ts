import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Account} from '../Account';
import { AccountService } from '../services/account.service';
import { RouterService } from '../services/router.service';
import { SharedServiceService } from '../services/shared-service.service';
import { DialogComponent } from '../dialog/dialog.component';
//import { UnSuccessfulDialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-get-all-accounts',
  templateUrl: './get-all-accounts.component.html',
  styleUrls: ['./get-all-accounts.component.css']
})
export class GetAllAccountsComponent implements OnInit {

 accountList:any;
 account:any;

  constructor(private accountService: AccountService,public dialog: MatDialog, private sharedServices: SharedServiceService, private routerService:RouterService) { }

  ngOnInit(): void {
    this.accountService.getAllAccounts().subscribe(data => {
      this.accountList = data;
      
    });
  }

  deleteAccount(accountId: string){

    this.accountService.deleteAccount(accountId).subscribe(data => {

      if(data)
      {
        this.openSuccessfulDialog();
        this.ngOnInit();
      }
      else{
        this.openunSuccessfulDialog();
        this.ngOnInit();
      }
      
    });
  }

  updateAccount(account: Account){

    this.sharedServices.setAccount(account);
    this.routerService.routeToUpdateAccount();
  }

   
  openSuccessfulDialog() {
    this.sharedServices.setdialogtitle("Successfull");
    this.sharedServices.setdialogcontent("Account Deleted Successfully !!");
    this.dialog.open(DialogComponent);
  }

  openunSuccessfulDialog() {
    this.sharedServices.setdialogtitle("Unsuccessfull");
    this.sharedServices.setdialogcontent("Account could not be Deleted !!");
    this.dialog.open(DialogComponent);
  }
  
  key: string ='id';
  reverse: boolean=false;
  sort(key:string)
  {
    this.key=key;
    this.reverse=!this.reverse;
  }

}
