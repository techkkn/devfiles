import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAccountByCategoryComponent } from './get-account-by-category.component';

describe('GetAccountByCategoryComponent', () => {
  let component: GetAccountByCategoryComponent;
  let fixture: ComponentFixture<GetAccountByCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAccountByCategoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetAccountByCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
