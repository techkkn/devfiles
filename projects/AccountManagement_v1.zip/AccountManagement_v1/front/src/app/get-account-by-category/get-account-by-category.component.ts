import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AccountService } from '../services/account.service';

@Component({
  selector: 'app-get-account-by-category',
  templateUrl: './get-account-by-category.component.html',
  styleUrls: ['./get-account-by-category.component.css']
})
export class GetAccountByCategoryComponent implements OnInit {

  accountList:any;
  account:any;
  key:any="";
  headers = ["Id", "Account Name", "Account Description", "Category", "Units"];


  constructor(private accountService: AccountService) { }


  ngOnInit(): void {
    
  }

  
  categoryForm=new FormGroup({
    
    category: new FormControl('default',[Validators.required])
  })

  get category(){
    return this.categoryForm.get('category');
  }

  getAccountByCategory(){

    this.key=this.categoryForm.value;

    this.accountService.getAllAccountsByCategory(this.key).subscribe(data => {
      this.accountList = data;
    });

  }


}
