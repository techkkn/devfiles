import { Component, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { SharedServiceService } from '../services/shared-service.service';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  title:string="";
  content:string="";

  constructor(private sharedservice:SharedServiceService,private routerService: RouterService) { }

  ngOnInit(): void {
    
  this.title=this.sharedservice.getdialogtitle();
  this.content=this.sharedservice.getdialogcontent();
}


refreshPage(){
  this.routerService.routeToAllAccount();
}
}
