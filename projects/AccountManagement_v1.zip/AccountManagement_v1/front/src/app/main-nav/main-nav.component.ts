import { Component,OnDestroy, inject } from '@angular/core';
//import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})
export class MainNavComponent {

 

  constructor(private route: ActivatedRoute) {  }

currentRoute="";


 ngOnInit() {
  // this.route.url.subscribe(([url]) => {
  //   const { path, parameters } = url;
  //   console.log(path); // e.g. /products
  //   console.log(parameters); // e.g. { id: 'x8klP0' }
  // });

  //console.log(this.route.snapshot); // ActivatedRouteSnapshot
  //  console.log(this.route.snapshot.url); // UrlSegment[]
  //  console.log(this.route.snapshot.url[0]); // UrlSegment
    console.log(this.route.snapshot.url[0].path); // e.g. /products
  //  console.log(this.route.snapshot.url[0].parameters); // e.g. { id: 'x8klP0' }

this.currentRoute=this.route.snapshot.url[0].path;

}

 
  logout(){
    localStorage.removeItem('token');
  }

}
