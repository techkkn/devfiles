package com.tech.management.service;

import java.util.List;

import com.tech.management.exception.AccountAlreadyExistsException;
import com.tech.management.model.Account;

public interface AccountService {
	
	public List<Account> getAllAccounts();
	public List<Account> getAccountsByCategory(String categoryName);
	public boolean addAccount(Account accountDetails) throws AccountAlreadyExistsException;
	public boolean updateAccount(Account accountDetails,String accountId);
	public boolean deleteAccount(String accountId);
}
