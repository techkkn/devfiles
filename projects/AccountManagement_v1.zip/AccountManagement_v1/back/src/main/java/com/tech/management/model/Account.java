package com.tech.management.model;

public class Account {
	
	private String accountId;
	private String accountName;
	private String accountDescription;
	private String accountCategory;
	private int branchId;
	
	
	public Account() {
		super();
	}


	public Account(String accountId, String accountName, String accountDescription, String accountCategory, int branchId) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.accountDescription = accountDescription;
		this.accountCategory = accountCategory;
		this.branchId = branchId;
	}


	public String getAccountId() {
		return accountId;
	}


	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}


	public String getAccountName() {
		return accountName;
	}


	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public String getAccountDescription() {
		return accountDescription;
	}


	public void setAccountDescription(String accountDescription) {
		this.accountDescription = accountDescription;
	}


	public String getAccountCategory() {
		return accountCategory;
	}


	public void setAccountCategory(String accountCategory) {
		this.accountCategory = accountCategory;
	}


	public int getBranchId() {
		return branchId;
	}


	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}


	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName=" + accountName + ", accountDescription="
				+ accountDescription + ", accountCategory=" + accountCategory + ", branchId=" + branchId + "]";
	}
	
	
	
}
