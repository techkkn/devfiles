package com.tech.management.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.tech.management.model.Account;

@Repository
public class AccountServiceRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	public List<Account> getAllAccounts() {
		
		
		List<Account> accountList=new ArrayList<>();
		
		 accountList=jdbcTemplate.query("SELECT *from Account", new RowMapper<Account>(){  
			   
			@Override
			public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
									
				Account account=new Account();
				account.setAccountId(rs.getString("accountId"));
				account.setAccountName(rs.getString("accountName"));
				account.setAccountDescription(rs.getString("accountDescription"));
				account.setAccountCategory(rs.getString("accountCategory"));
				account.setBranchId(rs.getInt("branchId"));
				
				
				return account;
			}  
		    }); 
		 
		return accountList;
		}
	
	public List<Account> getAccountsByCategory(String categoryName) {
		
		List<Account> accountList=new ArrayList<>();
		
		 accountList=jdbcTemplate.query("SELECT *from Account where lower(accountCategory)='"+categoryName.toLowerCase()+"'", new RowMapper<Account>(){  
			   
			@Override
			public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
									
				Account account=new Account();
				account.setAccountId(rs.getString("accountId"));
				account.setAccountName(rs.getString("accountName"));
				account.setAccountDescription(rs.getString("accountDescription"));
				account.setAccountCategory(rs.getString("accountCategory"));
				account.setBranchId(rs.getInt("branchId"));
				
				
				return account;
			}  
		    }); 
		return accountList;
		}
	
	
	public void addAccount(Account accountDetails) {
		
		 String INSERT_STATEMENT = "INSERT INTO Account(accountId,accountName,accountDescription,accountCategory, branchId) VALUES (?,?,?,?,?)" ;

			jdbcTemplate.batchUpdate(INSERT_STATEMENT, new BatchPreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					// TODO Auto-generated method stub
					ps.setString(1,accountDetails.getAccountId());
					ps.setString(2, accountDetails.getAccountName());
					ps.setString(3, accountDetails.getAccountDescription());
					ps.setString(4, accountDetails.getAccountCategory());
					ps.setInt(5, accountDetails.getBranchId());
				}
				
				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return 1;
				}
			});
	}
	
	public int updateAccount(Account accountDetails, String accountId) {
		
		String query="UPDATE Account set accountName='"+accountDetails.getAccountName()+"',accountDescription='"+accountDetails.getAccountDescription()+"',accountCategory='"+accountDetails.getAccountCategory()+"',branchId='"+accountDetails.getBranchId()+"' where accountId='"+accountId+"' ";  
			    return jdbcTemplate.update(query);  
	}
	
	public int deleteAccount(String accountId){  
	    String query="delete from account where accountId='"+accountId+"' ";  
	    return jdbcTemplate.update(query);  
	}  
	
	public String fetchPasswordForUserName(String userName) {
		
		String result="";
		
		String query="SELECT password from User where username='"+ userName+"'";
		
		result= jdbcTemplate.queryForObject(query,String.class);
		
		return result;
	}
	
}
