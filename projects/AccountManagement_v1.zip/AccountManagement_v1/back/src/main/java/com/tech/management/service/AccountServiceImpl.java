package com.tech.management.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tech.management.exception.AccountAlreadyExistsException;
import com.tech.management.model.Account;
import com.tech.management.repository.AccountServiceRepository;

@Repository
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountServiceRepository accountServiceRepository;
	
	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		
		List<Account> result=new ArrayList<>();
		
		try {
			result= accountServiceRepository.getAllAccounts();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
		
	}

	@Override
	public List<Account> getAccountsByCategory(String categoryName) {
		// TODO Auto-generated method stub
		List<Account> result=new ArrayList<>();
		
		try {
			result= accountServiceRepository.getAccountsByCategory(categoryName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean addAccount(Account accountDetails) throws AccountAlreadyExistsException {
		// TODO Auto-generated method stub
		boolean result;
		
		try {
			accountServiceRepository.addAccount(accountDetails);
			result=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			result=false;
			throw new AccountAlreadyExistsException("Account Already Exists!");
		}
		
		return result;
	}

	@Override
	public boolean updateAccount(Account accountDetails, String accountId) {
		// TODO Auto-generated method stub
		
		int result;
		
		try {
			result=accountServiceRepository.updateAccount(accountDetails,accountId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			result=0;
		}
		
		if(result==0)
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean deleteAccount(String accountId) {
		// TODO Auto-generated method stub
		int result;
		
		try {
			result=accountServiceRepository.deleteAccount(accountId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			result=0;
		}
		
		if(result==0)
		{
			return false;
		}
		return true;
	}
	

}
