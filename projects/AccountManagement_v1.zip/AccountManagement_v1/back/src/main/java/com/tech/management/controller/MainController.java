package com.tech.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tech.management.exception.AccountAlreadyExistsException;
import com.tech.management.model.Account;
import com.tech.management.service.AccountService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/accountManagement")
public class MainController {
	
	@Autowired
	AccountService accountService;
	
	ObjectMapper objectMapper = new ObjectMapper().configure(SerializationFeature.INDENT_OUTPUT, true);
	
	@GetMapping("/getAllAccounts")
	public Object getAllAccounts(){
		List<Account> result= accountService.getAllAccounts();
		return result;
	}
	
	@GetMapping("/getAccountsByCategory/{key}")
	public Object getAccountsByCategory(@PathVariable("key") String categoryName) throws JsonProcessingException{
		
		List<Account> result= accountService.getAccountsByCategory(categoryName);
		String listToJson = objectMapper.writeValueAsString(result);
		return listToJson;
	}

	@PostMapping("/addAccount")
	public boolean addAccount(@RequestBody Account producDetails) throws JsonProcessingException, AccountAlreadyExistsException{
		
		boolean response = accountService.addAccount(producDetails);
		return response;
	}
	
	@PostMapping("updateAccount/{accountId}")  
    public boolean updateAccount(@RequestBody Account accountDetails,@PathVariable("accountId") String accountId) {  
        boolean result= accountService.updateAccount(accountDetails, accountId);  
        return result;  
    }  
	
	@DeleteMapping("deleteAccount/{accountId}")  
    public boolean deleteAccount(@PathVariable("accountId") String accountId) {  
        boolean result= accountService.deleteAccount(accountId);  
        return result;  
    } 
	
}
