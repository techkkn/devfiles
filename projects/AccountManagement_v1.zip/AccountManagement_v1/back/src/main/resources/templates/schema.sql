CREATE DATABASE Accounts;


use Accounts;

drop table Account;
create table Account(
accountId varchar(256) Unique not null,
accountName varchar(256),
accountDescription varchar(3500),
accountCategory varchar(256),
branchId int
);

drop table User;
create table User(
username varchar(256),
password varchar(256)
);


use Accounts;
insert into User(username,password) Values("testadmin@mail.com","$2a$04$rsWpmvH5x.zZWIZwCyvFOueKKmU.azn/OpsYXfeJ34GFAKTukhhHW");
#password - testadmin
