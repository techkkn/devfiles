package com.tech.management.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.tech.management.model.Account;
import com.tech.management.service.AccountService;

@RunWith(MockitoJUnitRunner.class)
public class TestMainController {
	
	@InjectMocks
	private MainController mainController;
	
	@Mock
	private AccountService accountService;
	
	@Test
	public void testGetAllAccounts() {
		Account account =new Account();
		
		account.setAccountId("A01");
		account.setAccountName("Airport_test");
		
		List<Account> accountList=new ArrayList<>();
		
		accountList.add(account);
		
		when(accountService.getAllAccounts()).thenReturn(accountList);
		
		Object result=mainController.getAllAccounts();
		
		assertNotNull(result);
	}

}
